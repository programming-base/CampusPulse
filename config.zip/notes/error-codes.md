# CampusPulse Backend Error Codes

This document lists the current API error status codes and error messages used across the backend.

## Standard Error Format

Most endpoints return errors in one of these shapes:

```json
{ "error": "message" }
```

or

```json
{ "message": "message" }
```

## Error Code Reference

| HTTP Code | Meaning | Common Messages in Codebase |
|---|---|---|
| 400 | Bad Request / Validation Failure | `Bad request`, `Please enter valid credentials`, `Email is required`, `The email is not valid`, `No field to update`, `Insufficient information`, `Invalid postId`, `Invalid otp`, `Invalid OTP`, `Token not found`, `Invalid token`, `missing fields` |
| 401 | Unauthorized / Token Problems | `Token is missing`, `Invalid token`, `session expired`, `Refresh token expired`, `Invalid or expired reset token`, `Invalid reset token payload`, `email doesn't exists`, `Invalid password` |
| 403 | Forbidden | `Unauthorized`, `Unathorized` |
| 404 | Resource Not Found | `user not found or invalid user ID`, `post ID not found`, `Post not found`, `post not found`, `comment Id not found`, `Like not found`, `user not found` |
| 409 | Conflict | `Email already registered` |
| 429 | Too Many Requests | `Maximum OTP attempts reached. Request a new OTP`, `reached the highest attempts, try again after some times` |
| 500 | Internal Server Error | `Internal server error`, `Server error`, `Database error`, `Token generation failed`, `Password hashing failed`, `Failed to delete comment`, `Failed to update post count`, `Password processing failed`, `couldnt create` |

## Where These Errors Are Returned

- `routes/auth/*`
- `routes/posts/*`
- `routes/users/*`
- `middlewares/*`

## Notes

- There are a few inconsistent message spellings/capitalization (for example `Unathorized`, `Invalid otp` vs `Invalid OTP`, and mixed `error`/`message` keys).
- If you want, this can be standardized into a single error response contract in a follow-up update.
