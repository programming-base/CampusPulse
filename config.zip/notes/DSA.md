## 🧠 Arrays & Strings (40)

* Two Sum
* Best Time to Buy and Sell Stock
* Contains Duplicate
* Product of Array Except Self
* Maximum Subarray
* Maximum Product Subarray
* Find Minimum in Rotated Sorted Array
* Search in Rotated Sorted Array
* 3Sum
* Container With Most Water
* Longest Substring Without Repeating Characters
* Longest Repeating Character Replacement
* Minimum Window Substring
* Valid Anagram
* Group Anagrams
* Valid Palindrome
* Longest Palindromic Substring
* Palindromic Substrings
* Encode and Decode Strings
* String to Integer (atoi)
* Rotate Array
* Move Zeroes
* Merge Sorted Array
* Squares of Sorted Array
* Subarray Sum Equals K
* Continuous Subarray Sum
* Longest Consecutive Sequence
* Spiral Matrix
* Set Matrix Zeroes
* Sort Colors
* Missing Number
* Find All Numbers Disappeared in Array
* Majority Element
* First Missing Positive
* Gas Station
* Jump Game
* Jump Game II
* Partition Labels
* Candy
* Trapping Rain Water

---

## 🔗 Linked List (15)

* Reverse Linked List
* Merge Two Sorted Lists
* Linked List Cycle
* Linked List Cycle II
* Remove Nth Node From End
* Reorder List
* Add Two Numbers
* Intersection of Two Linked Lists
* Palindrome Linked List
* Copy List with Random Pointer
* Swap Nodes in Pairs
* Reverse Nodes in k-Group
* Rotate List
* Flatten a Multilevel Doubly Linked List
* Partition List

---

## 📚 Stack & Queue (20)

* Valid Parentheses
* Min Stack
* Evaluate Reverse Polish Notation
* Daily Temperatures
* Car Fleet
* Largest Rectangle in Histogram
* Implement Queue using Stacks
* Sliding Window Maximum
* Next Greater Element I
* Next Greater Element II
* Remove K Digits
* Basic Calculator
* Decode String
* Simplify Path
* Online Stock Span
* Asteroid Collision
* Score of Parentheses
* Validate Stack Sequences
* Remove Duplicate Letters
* Exclusive Time of Functions

---

## 🌳 Trees (30)

* Maximum Depth of Binary Tree
* Same Tree
* Invert Binary Tree
* Binary Tree Level Order Traversal
* Lowest Common Ancestor of BST
* Lowest Common Ancestor of Binary Tree
* Validate Binary Search Tree
* Kth Smallest Element in BST
* Construct Binary Tree from Preorder and Inorder
* Binary Tree Right Side View
* Diameter of Binary Tree
* Balanced Binary Tree
* Path Sum
* Path Sum II
* Serialize and Deserialize Binary Tree
* Subtree of Another Tree
* Symmetric Tree
* Sum Root to Leaf Numbers
* Flatten Binary Tree to Linked List
* Binary Tree Maximum Path Sum
* Count Good Nodes
* All Nodes Distance K
* Vertical Order Traversal
* Boundary of Binary Tree
* Zigzag Level Order Traversal
* Convert Sorted Array to BST
* Populating Next Right Pointers
* Minimum Depth of Binary Tree
* Check Completeness of Binary Tree
* House Robber III

---

## 🌐 Graphs (25)

* Number of Islands
* Clone Graph
* Course Schedule
* Course Schedule II
* Pacific Atlantic Water Flow
* Rotting Oranges
* Walls and Gates
* Network Delay Time
* Word Ladder
* Graph Valid Tree
* Number of Connected Components
* Redundant Connection
* Is Graph Bipartite
* Accounts Merge
* Evaluate Division
* Minimum Height Trees
* Cheapest Flights Within K Stops
* Reconstruct Itinerary
* Alien Dictionary
* Detect Cycle in Directed Graph
* BFS Traversal
* DFS Traversal
* Flood Fill
* Surrounded Regions
* Shortest Path in Binary Matrix

---

## 🔍 Binary Search (15)

* Binary Search
* Search Insert Position
* Find Peak Element
* Search a 2D Matrix
* Koko Eating Bananas
* Capacity To Ship Packages Within D Days
* Median of Two Sorted Arrays
* Find Minimum in Rotated Sorted Array II
* Split Array Largest Sum
* Time Based Key-Value Store
* Single Element in Sorted Array
* Find First and Last Position
* Peak Index in Mountain Array
* Aggressive Cows (variant)
* Allocate Minimum Pages

---

## 🧮 Hashing (10)

* Subarray Sum Equals K
* Top K Frequent Elements
* Longest Consecutive Sequence
* Isomorphic Strings
* Happy Number
* Word Pattern
* Intersection of Two Arrays
* Ransom Note
* First Unique Character
* Majority Element II

---

## ⚡ Greedy (10)

* Jump Game
* Jump Game II
* Gas Station
* Partition Labels
* Task Scheduler
* Merge Intervals
* Non-overlapping Intervals
* Minimum Arrows to Burst Balloons
* Candy
* Assign Cookies

---

## 🧩 Dynamic Programming (35)

* Climbing Stairs
* House Robber
* House Robber II
* Coin Change
* Longest Increasing Subsequence
* Longest Common Subsequence
* Word Break
* Combination Sum IV
* Decode Ways
* Unique Paths
* Unique Paths II
* Minimum Path Sum
* Edit Distance
* Maximal Square
* Burst Balloons
* Partition Equal Subset Sum
* Target Sum
* Best Time to Buy and Sell Stock II
* Best Time to Buy and Sell Stock III
* Best Time to Buy and Sell Stock IV
* Longest Palindromic Subsequence
* Palindrome Partitioning II
* Interleaving String
* Distinct Subsequences
* Regular Expression Matching
* Wildcard Matching
* Triangle
* Paint House
* Dungeon Game
* Fibonacci
* Knapsack 0/1
* Rod Cutting
* Matrix Chain Multiplication
* Subset Sum
* Coin Change II
