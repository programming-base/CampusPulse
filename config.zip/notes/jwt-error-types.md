# JWT Token Error Types (Node.js + Express + jsonwebtoken)

This note explains JWT-related error types, why they happen, how to detect them, and how to respond safely in an API.

## Quick Summary

In the `jsonwebtoken` package, verification errors are mainly:

1. `TokenExpiredError`
2. `JsonWebTokenError`
3. `NotBeforeError`

Most auth failures in APIs map to HTTP `401 Unauthorized`, while malformed auth headers often map to `400 Bad Request`.

---

## 1) TokenExpiredError

### What it means

The token was valid when issued, but its `exp` claim time has passed.

### Common causes

- Access token lifetime is short and user did not refresh in time.
- Client clock is behind/ahead (clock skew).
- Token replayed after expiration.

### Typical error shape

```js
{
  name: 'TokenExpiredError',
  message: 'jwt expired',
  expiredAt: '2026-04-26T10:20:30.000Z'
}
```

### Suggested API response

- Status: `401`
- Message: `Access token expired`
- Action: Ask client to call refresh-token endpoint.

### Secure handling tip

Do not return full token details to client. Log expiry time server-side only.

---

## 2) JsonWebTokenError

### What it means

The token failed structural/signature/claim validation.

### Common message variants and meaning

1. `jwt malformed`

- Token is not in proper JWT format (`header.payload.signature`).

2. `invalid token`

- Token cannot be parsed as a valid JWT.

3. `invalid signature`

- Signature check failed (wrong secret/public key, token tampered, wrong algorithm config).

4. `jwt signature is required`

- Missing signature in token input.

5. `jwt audience invalid. expected: ...`

- `aud` claim does not match expected audience.

6. `jwt issuer invalid. expected: ...`

- `iss` claim does not match expected issuer.

7. `jwt id invalid. expected: ...`

- `jti` claim mismatch.

8. `jwt subject invalid. expected: ...`

- `sub` claim mismatch.

### Suggested API response

- Status: usually `401`
- Message: `Invalid token`

### Secure handling tip

Return a generic message in production (`Invalid token`), but log exact internal reason (`invalid signature`, `jwt malformed`, etc.).

---

## 3) NotBeforeError

### What it means

Token includes an `nbf` (not before) claim and is being used too early.

### Common causes

- Token generated with future activation time.
- Clock skew between systems.

### Typical error shape

```js
{
  name: 'NotBeforeError',
  message: 'jwt not active',
  date: '2026-04-26T11:00:00.000Z'
}
```

### Suggested API response

- Status: `401`
- Message: `Token not active yet`

---

## Non-library JWT/Auth Errors You Should Handle

These are not `jsonwebtoken` class names, but common auth failures in APIs.

1. Missing Authorization header

- Example: no `Authorization` header at all.
- Suggested status: `401`
- Message: `Authorization header missing`

2. Bad Authorization format

- Example: not `Bearer <token>`.
- Suggested status: `400` or `401`
- Message: `Invalid authorization format`

3. Wrong token type used

- Example: refresh token used on access-protected route.
- Suggested status: `401`
- Message: `Invalid token type`

4. Revoked token / blacklisted token

- Suggested status: `401`
- Message: `Token revoked`

5. User no longer exists / disabled account

- Suggested status: `401` (or `403` depending policy)
- Message: `User not authorized`

---

## Recommended HTTP Status Mapping

1. `400 Bad Request`

- Malformed auth header or invalid request structure.

2. `401 Unauthorized`

- Token missing/expired/invalid/not active/revoked.

3. `403 Forbidden`

- Token is valid, but user lacks permission (role/scope issue).

---

## Example Verification Middleware Pattern

```js
import jwt from 'jsonwebtoken';

export default function verifyAccessToken(req, res, next) {
  try {
    const auth = req.headers.authorization;

    if (!auth) {
      return res.status(401).json({ error: 'Authorization header missing' });
    }

    const [scheme, token] = auth.split(' ');
    if (scheme !== 'Bearer' || !token) {
      return res.status(400).json({ error: 'Invalid authorization format' });
    }

    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Access token expired' });
    }

    if (err.name === 'NotBeforeError') {
      return res.status(401).json({ error: 'Token not active yet' });
    }

    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token' });
    }

    return res.status(500).json({ error: 'Internal server error' });
  }
}
```

---

## Logging Best Practices

1. Log internal error reason (`err.name`, `err.message`) on server.
2. Do not log full raw token in plaintext logs.
3. Keep client-facing messages generic in production.
4. Include request correlation IDs for traceability.

---

## Security Checklist

1. Use strong secrets/keys and rotate periodically.
2. Separate access-token and refresh-token secrets.
3. Set short access-token expiry and controlled refresh flow.
4. Validate issuer (`iss`) and audience (`aud`) when possible.
5. Reject tokens signed with unexpected algorithms.
6. Store refresh tokens securely (httpOnly cookie or secure store).
7. Add token revocation strategy (blacklist/versioning/rotation).

---

## One-Line Reference

`deleteOne()` in MongoDB/Mongoose returns delete result metadata (`acknowledged`, `deletedCount`), while JWT verification failures return auth errors like `TokenExpiredError`, `JsonWebTokenError`, and `NotBeforeError`.
