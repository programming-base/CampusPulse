# Project Context & Developer Reference Guide (CONTEXT.md)

This document serves as the permanent memory, structural mapping, and technical onboarding reference for the `campuspulse-backend` project.

---

## 1. Project Overview

### What the Application Does
**CampusPulse** (internal package name `campuspulse-backend`) is a specialized social collaboration and communication backend platform designed for college campus environments. It provides users (students and faculty) a secure way to share thoughts, create posts with scope-restricted visibility, upload media files, and message each other via direct messages (DMs) or group chats.

### Target Users
* **College Students**: Interacting with peers in their year, department, or college.
* **Campus Administrators & Department Heads**: Sharing announcements or managing groups.

### Core Features
1. **JWT-based Authentication & Access Control**: Access token validation with short lifespan (5m), refresh tokens stored securely in a DB (7d), and password reset mechanisms using OTPs generated and emailed via Nodemailer.
2. **Post System with Visibility Scopes**: Students can make posts that are visible college-wide, department-specific, or academic-year-specific. Posts can also be created anonymously to encourage open discussions.
3. **Likes & Comments**: Users can like posts and comments, and leave nested commentary on posts.
4. **Follower/Following Graph**: User-to-user follows allowing students to build a personal network.
5. **Real-Time Direct & Group Chat**: Support for direct messaging and administrator-moderated group chats, including paginated message feeds and media sharing.
6. **Cloudinary Integration**: Multer-based image buffer processing to upload profile photos, post attachments, and chat files to Cloudinary.
7. **Scoped Notification Engine**: Notifying recipients of likes, comments, follows, mentions, and system updates, with granular opt-out settings for each user.

### Current Development Stage
The project is in an **active backend beta development stage**. All core REST API endpoints and database models are configured. However, real-time WebSocket connection handling remains un-integrated in `server.js`, certain core flows suffer from severe database consistency issues (e.g., Follower/Following mismatch), and several endpoints contain critical logic syntax bugs. The frontend codebase is not part of this repository (only a single-file test HTML page is present in the root).

---

### 2. Repository Structure

Below is the file structure mapping of the codebase:

```text
campuspulse-backend/
├── .env                              # Local environment variables configuration
├── .gitignore                        # Git exclusion configuration
├── app.js                            # Express application entry, middlewares, & route register
├── server.js                         # Database wrapper execution & HTTP server initialization
├── index.html                        # Standard HTML + JS WebSocket test client page
├── package.json                      # Dependency registry & scripts definitions
├── package-lock.json                 # Locked dependency versioning tree
├── database/                         # Database connection & schemas root
│   ├── mongoDB.js                    # Mongoose MongoDB connection initialization wrapper
│   └── schema/                       # Database models definitions
│       ├── authSchema/               # Authorization-related schemas
│       │   ├── otp.js                # Schema for OTP emails and code storage
│       │   ├── tokenSchema.js        # Schema for rotated refresh tokens
│       │   └── userSchema.js         # Schema for user profile and credentials
│       ├── chatSchema/               # Messaging-related schemas
│       │   ├── chatSchema.js         # Schema for DM and group chat rooms
│       │   └── messageSchema.js      # Schema for single message documents
│       ├── followSchema/             # Graph relationship schemas
│       │   ├── followerShema.js      # Schema for user followers mapping (contains shema typo)
│       │   └── followingSchema.js    # Schema for user following mapping
│       ├── notificationSchema/       # Notification delivery schemas
│       │   ├── notificationSchema.js # Schema for system, comment, and follow notices
│       │   └── notificationSettingsSchema.js # User preferences settings schema
│       └── postsSchema/              # Forums and posts schemas
│           ├── commentSchema.js      # Schema for comment documents on posts
│           ├── likeSchema.js         # Schema for polymorphic post & comment likes
│           └── postSchema.js         # Schema for post feeds documents
├── middlewares/                      # Custom request validations & filters
│   ├── chatsMiddleware/              # Chat specific middleware
│   │   ├── chatVerification.js       # Middleware to verify user participation in a chat Room
│   │   └── getUserChats.js           # Middleware to fetch rooms populated with details
│   ├── postValidation.js             # Middleware to verify existence of a post by postId
│   ├── userValidation.js             # Middleware to verify existence of a user by userId
│   ├── verifyAccessToken.js          # JWT access token validation middleware
│   └── verifyRefreshToken.js         # JWT refresh token validation middleware
├── routes/                           # API Route Handlers grouped by feature module
│   ├── auth/                         # Authentication, logout, refresh, and reset routes
│   │   ├── forgotPassword.js         # Forgot password flow & Ethereal mail configuration
│   │   ├── getUser.js                # User profile retrieval (/auth/me)
│   │   ├── loginRoute.js             # Email & password verification, sets access/refresh tokens
│   │   ├── logoutRoute.js            # User session removal & token revocation
│   │   ├── refreshToken.js           # Access token rotation via refresh token
│   │   ├── registrationRoute.js      # Account signup logic
│   │   ├── resetPassword.js          # Reset password process
│   │   └── verifyRoute.js            # Access token active check endpoint
│   ├── chats/                        # Conversational route endpoints
│   │   ├── chatDeleteRoute.js        # Member removal, leaving, and deleting messages
│   │   ├── chatGetRoute.js           # Fetching chats, message feeds, and room metadata
│   │   ├── chatPostRoute.js          # Group room, messages, members additions, and reads
│   │   └── chatPutRoute.js           # Room configurations editor
│   ├── notifications/                # User alerts route endpoints
│   │   ├── notificationDeleteRoute.js# Notice removal and clearing read logs
│   │   ├── notificationGetRoute.js   # Listing user notifications, unread counts, and settings
│   │   └── notificationsPutRoute.js  # Read states toggle & alerts preference update
│   ├── posts/                        # Forums and sharing route endpoints
│   │   ├── postsDeleteRoute.js       # Comments, likes, and posts deletions
│   │   ├── postsGetsRoute.js         # Paginated posts feeds, comments feeds, and detail lookups
│   │   ├── postsPostRoute.js         # Post publishing, commenting, and liking
│   │   └── postsPutRoute.js          # Post body editors
│   ├── upload/                       # Media assets route endpoints
│   │   ├── cloudinary.js             # Cloudinary environment config & multer memory buffer
│   │   ├── uploadChatImage.js        # Chat image upload to Cloudinary
│   │   ├── uploadImage.js            # Multi-image post upload to Cloudinary
│   │   └── uploadProfilePic.js       # Profile picture configuration route
│   └── users/                        # Users interactions route endpoints
│   │   ├── userDeleteRoute.js        # Unfollowing interactions
│   │   ├── usersGetRoute.js          # User searches, followers, following list, and profile feeds
│   │   ├── usersPostRoute.js         # User following creations
│   │   └── usersPutRoute.js          # Profile fields editor (except password/email)
├── tests/                            # Automation test suites (Jest & Supertest)
│   ├── App.test.js                   # Jest system configuration checking test
│   ├── setup.js                      # Jest environment configuration and teardown
│   ├── auth/                         # Authentication and password recovery suites (13 files)
│   ├── chats/                        # Chat rooms and direct message flow suites
│   ├── fixtures/                     # Test mock fixtures and data seed generators
│   ├── helpers/                      # Testing helper routines
│   ├── middleware/                   # Request token/ID parameter validation tests
│   ├── mocks/                        # Cloudinary CDN and nodemailer mocks
│   ├── notifications/                # User alerts preference and trigger tests
│   ├── posts/                        # Post creation, commenting, and liking tests
│   ├── security/                     # Authorization security validation tests
│   ├── uploads/                      # Image buffer media upload tests
│   └── users/                        # Profiles search and follower graph tests
└── notes/                            # Internal guides & engineering logs
    ├── DSA.md                        # Data structures and algorithms logs
    ├── error-codes.md                # Mapping of HTTP codes used in API
    ├── jwt-error-types.md            # Details of JWT token validation errors
    ├── Markdown to PDF.pdf           # Markdown compilation guide
    ├── jwt-reference.pdf             # JWT security constraints guide
    └── mongoose-reference.pdf        # Mongoose database model optimization reference
```

### Module Responsibilities & Dependencies
* `database/` maps structural representations to MongoDB and provides object model helpers. It is used extensively by all API controllers.
* `middlewares/` extracts token verification, user lookup, and entity confirmation, reducing duplication in route controllers.
* `routes/` aggregates Express route parameters and delegates business actions. It heavily depends on database models and request filters.
* `webSockets/` *(Proposed)*: Intended to expose connection hooks for real-time bidirectional data transfers. Currently not physically present in the workspace.

---

## 3. Architecture

### Architectural Pattern
The application uses a **Layered MVC Architecture (Model-Route-Middleware)** design:
1. **Controller Layer (Routes)**: Express routers receive network calls, parse input, execute handlers, and return JSON responses.
2. **Business Logic Layer (Middlewares / Helpers)**: Authenticates access, validates inputs, formats exceptions, and pipes assets to Cloudinary.
3. **Data Layer (Schemas / Mongoose)**: Enforces validation rules, handles relationships, and persists entities into MongoDB.

### Data Flow
```mermaid
graph TD
    Client[Client Browser / Mobile App]
    Express[Express App Routing]
    AuthM[verifyAccessToken Middleware]
    ValidationM[postValidation / userValidation / chatVerification]
    Router[Feature Route Handlers]
    Mongoose[Mongoose Models]
    MongoDB[(MongoDB Server)]
    Cloudinary[Cloudinary CDN]

    Client -->|HTTP Request| Express
    Express -->|Access Tokens Check| AuthM
    AuthM -->|Invalid| Client
    AuthM -->|Valid| ValidationM
    ValidationM -->|Resource Missing| Client
    ValidationM -->|Resource Ready| Router
    Router -->|Database Queries| Mongoose
    Mongoose <--> MongoDB
    Router -->|Upload Buffers| Cloudinary
    Router -->|JSON Response| Client
```

### Request Lifecycle
1. **Incoming Request**: Client fires an HTTP request to an Express port.
2. **Payload Parsing**: Express body parser middleware digests JSON payloads and Urlencoded buffers.
3. **Authentication Filter**: If target path is protected, `verifyAccessToken` reads authorization headers. If header is missing/expired, throws `401 Unauthorized` directly.
4. **Validation Filters**: Intermediary check evaluates parameters (e.g., `postId`, `userId`, `chatId`). It looks up MongoDB records. If not found, throws `404 Not Found`. Otherwise, assigns records to custom request fields (like `req.post`, `req.chat`).
5. **Business Controller**: Runs action-oriented code (e.g., updating comment count, uploading image arrays).
6. **Polymorphic Post-Action**: Triggers cascade deletions or third-party operations (such as Cloudinary uploads).
7. **Response Output**: Formulates standard client payload (e.g., `{ success: true, data: [...] }`).

### Frontend-Backend Communication
Communication is established via:
* **REST API Endpoints**: Returning unified JSON structures for state updates.
* **WebSocket Streams** *(Planned)*: Client will pass an authentication token via query parameters `ws://localhost:3000?token=JWT_ACCESS_TOKEN`, verified by a query token authorization middleware before upgrading the connection. Currently, the server lacks connection handlers.

---

## 4. Database Analysis

Below is the database modeling structure mapped using Mongoose schemas. All timestamps are auto-managed by Mongoose via `{ timestamps: true }` flags unless stated otherwise.

### 4.1. Users Model (`Users` Collection)
* **Purpose**: Stores account profiles, login credentials, and academic affiliation metadata.
* **Fields**:
  * `_id` (`ObjectId`, primary key, auto-generated)
  * `displayName` (`String`, required, trimmed)
  * `userName` (`String`, required, unique, matches credentials)
  * `email` (`String`, required, unique, lowercase, trimmed, validated via `/^\S+@\S+\.\S+$/`)
  * `password` (`String`, required, hashed with bcrypt)
  * `college` (`String`, required)
  * `department` (`String`, required)
  * `academicYear` (`Number`, required)
  * `photoURL` (`Object` containing: `url` (`String`), `publicID` (`String`))
* **Constraints**: Unique checks on `userName` and `email`. Format evaluation on `email`.
* **Example Record**:
  ```json
  {
    "_id": "60d5ec49867c4217bc42e12a",
    "displayName": "John Doe",
    "userName": "johndoe123",
    "email": "john.doe@college.edu",
    "password": "$2b$10$76543210hashvaluehere...",
    "college": "TCET",
    "department": "Information Technology",
    "academicYear": 3,
    "photoURL": {
      "url": "https://res.cloudinary.com/campuspulse/profile-photo/...",
      "publicID": "campuspulse/profile-photo/60d5ec49867c4217bc42e12a"
    }
  }
  ```

### 4.2. Token Model (`tokens` Collection)
* **Purpose**: Records active refresh tokens to manage persistent sessions and facilitate token revocation.
* **Fields**:
  * `userId` (`ObjectId`, ref: `'Users'`, required)
  * `token` (`String`, required, hashed representation of active refresh token)
  * `type` (`String`, enum: `['refresh', 'reset', 'access']`, required)
  * `createdAt` (`Date`, default: `Date.now`)
  * `expiresIn` (`Date`, required expiry timestamp)
  * `isRevoked` (`Boolean`, default: `false`)
* **Example Record**:
  ```json
  {
    "_id": "60d5ec49867c4217bc42e12b",
    "userId": "60d5ec49867c4217bc42e12a",
    "token": "$2b$10$tokenhashhere...",
    "type": "refresh",
    "createdAt": "2026-06-14T18:00:00.000Z",
    "expiresIn": "2026-06-21T18:00:00.000Z",
    "isRevoked": false
  }
  ```

### 4.3. OTP Model (`otps` Collection)
* **Purpose**: Handles temporary passcode storage for verification and password reset flows.
* **Fields**:
  * `email` (`String`, required)
  * `otp` (`String`, required, bcrypt-hashed passcode)
  * `token` (`String`, required, JWT verification token payload)
  * `otpType` (`String`, enum: `['forgot-password', 'reset-password']`, required)
  * `createdAt` (`Date`, default: `Date.now`, expires: 120s TTL index)
  * `attempts` (`Number`, default: 0, max: 5)
* **Example Record**:
  ```json
  {
    "_id": "60d5ec49867c4217bc42e12c",
    "email": "john.doe@college.edu",
    "otp": "$2b$10$otphashhere...",
    "token": "eyJhbGciOi...",
    "otpType": "forgot-password",
    "createdAt": "2026-06-14T23:30:00.000Z",
    "attempts": 1
  }
  ```

### 4.4. Chats Model (`chats` Collection)
* **Purpose**: Represents conversation channels between two users (dm) or groups of users.
* **Fields**:
  * `admin` (`ObjectId`, ref: `'Users'`, representing the room administrator)
  * `type` (`String`, enum: `["dm", "group"]`, default logic maps room size)
  * `description` (`String`)
  * `participants` (`[ObjectId]`, ref: `'Users'`)
  * `lastMessage` (`ObjectId`, ref: `'Message'`, latest conversation snippet)
  * `messageCount` (`Number`, default: 0)
  * `lastActivity` (`Date`, default: `Date.now`)
* **Example Record**:
  ```json
  {
    "_id": "60d5ec49867c4217bc42e12d",
    "admin": "60d5ec49867c4217bc42e12a",
    "type": "group",
    "description": "Group for IT Department Projects",
    "participants": ["60d5ec49867c4217bc42e12a", "60d5ec49867c4217bc42e12f"],
    "messageCount": 25,
    "lastActivity": "2026-06-14T23:35:00.000Z"
  }
  ```

### 4.5. Message Model (`messages` Collection)
* **Purpose**: Records messages sent in chats.
* **Fields**:
  * `chatId` (`ObjectId`, ref: `'Chats'`, required)
  * `sender` (`ObjectId`, ref: `'Users'`, required)
  * `text` (`String`, trimmed message contents)
  * `type` (`String`, enum: `["text", "image", "video", "file"]`, default: `"text"`)
  * `mediaUrl` (`String`)
  * `readBy` (`[ObjectId]`, ref: `'Users'`)
* **Example Record**:
  ```json
  {
    "_id": "60d5ec49867c4217bc42e12e",
    "chatId": "60d5ec49867c4217bc42e12d",
    "sender": "60d5ec49867c4217bc42e12a",
    "text": "Hello Team!",
    "type": "text",
    "readBy": ["60d5ec49867c4217bc42e12a"]
  }
  ```

### 4.6. Followers Model (`followers` Collection)
* **Purpose**: Tracks inbound follow relations.
* **Fields**:
  * `userId` (`ObjectId`, ref: `'Users'`, required, target user being followed)
  * `followerId` (`ObjectId`, ref: `'Users'`, required, user performing the follow action)

### 4.7. Followings Model (`followings` Collection)
* **Purpose**: Tracks outbound follow relations.
* **Fields**:
  * `userId` (`ObjectId`, ref: `'Users'`, required, user performing the follow action)
  * `followingId` (`ObjectId`, ref: `'Users'`, required, target user being followed)

### 4.8. Comments Model (`comments` Collection)
* **Purpose**: Feeds post details sections with feedback records.
* **Fields**:
  * `postId` (`ObjectId`, ref: `'Posts'`, required)
  * `userId` (`ObjectId`, ref: `'Users'`, required)
  * `content` (`String`, required comment body)
  * `likes` (`Number`, default: 0)

### 4.9. Likes Model (`likes` Collection)
* **Purpose**: Polymorphic storage of target likes (supports both posts and comments).
* **Fields**:
  * `targetId` (`ObjectId`, required target identifier)
  * `userId` (`ObjectId`, ref: `'Users'`, required)
  * `targetType` (`String`, enum: `['comment', 'post']`, required)

### 4.10. Notifications Model (`notifications` Collection)
* **Purpose**: Handles activity updates pushed to the user feed.
* **Fields**:
  * `recipient` (`ObjectId`, ref: `'Users'`, required, indexed)
  * `sender` (`ObjectId`, ref: `'Users'`)
  * `type` (`String`, enum: `["like", "comment", "follow", "mention", "system"]`, required)
  * `title` (`String`, required)
  * `message` (`String`, required)
  * `post` (`ObjectId`, ref: `'Posts'`, default: null)
  * `isRead` (`Boolean`, default: false)
* **Indexes**: Compound index on `{ recipient: 1, createdAt: -1 }`.

### 4.11. Notification Settings Model (`notification_settings` Collection)
* **Purpose**: Fine-grain user toggles for filtering outbound alerts.
* **Fields**:
  * `userId` (`ObjectId`, ref: `'Users'`, required)
  * `likes` (`Boolean`, default: true)
  * `comments` (`Boolean`, default: true)
  * `follows` (`Boolean`, default: true)
  * `mentions` (`Boolean`, default: true)
  * `systemAlerts` (`Boolean`, default: true)
  * `emailNotifications` (`Boolean`, default: false)

---

### Entity Relationship Diagram (ERD)
The relationships between the main models are mapped below:

```mermaid
erDiagram
    Users ||--o{ Token : "has active session"
    Users ||--o{ OTP : "requests code"
    Users ||--o{ Chats : "participants/admin"
    Users ||--o{ Message : "sends/reads"
    Users ||--o{ Followers : "followed/follower"
    Users ||--o{ Followings : "followed/following"
    Users ||--o{ Comments : "writes"
    Users ||--o{ Likes : "submits"
    Users ||--o{ Notifications : "receives/triggers"
    Users ||--o{ Notification_Settings : "customizes settings"
    Users ||--o{ Posts : "creates"

    Posts ||--o{ Comments : "contains"
    Posts ||--o{ Likes : "receives"
    Posts ||--o{ Notifications : "referenced in"
    
    Chats ||--o{ Message : "groups messages"
```

---

## 5. API Documentation

All routes default to the `/api` route prefix set in `app.js`.

### 5.1. Authentication Module (`routes/auth/*`)

#### POST `/api/auth/register`
* **Purpose**: Signs up a new user account and returns valid session tokens.
* **Auth Required**: No.
* **Request Body**:
  ```json
  {
    "displayName": "Jane Doe",
    "email": "jane@college.edu",
    "userName": "janedoe",
    "password": "strongpassword",
    "college": "TCET",
    "department": "Computer Science",
    "academicYear": 2
  }
  ```
* **Response (201 Created)**:
  ```json
  {
    "message": "Account created",
    "accessToken": "JWT_ACCESS_TOKEN",
    "refreshToken": "JWT_REFRESH_TOKEN",
    "User": {
      "photoURL": "uewihfnfdsk",
      "displayName": "Jane Doe",
      "email": "jane@college.edu",
      "userName": "janedoe",
      "college": "TCET",
      "department": "Computer Science",
      "academicYear": 2,
      "_id": "60d5ec49867c4217bc42e12f"
    }
  }
  ```
* **Errors**: `400 Bad Request` (fields missing), `409 Conflict` (Email already registered), `500` (Internal server error).

#### POST `/api/auth/login`
* **Purpose**: Verifies login credentials and returns a new session.
* **Auth Required**: No.
* **Request Body**: `{ "email": "jane@college.edu", "password": "strongpassword" }`
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "message": "logged in successfully",
    "accessToken": "JWT_ACCESS",
    "refreshToken": "JWT_REFRESH"
  }
  ```
* **Errors**: `400` (credentials missing), `401 Unauthorized` (Invalid credentials), `500` (Internal server error).

#### POST `/api/auth/logout`
* **Purpose**: Invalidates the active refresh token session in the database.
* **Auth Required**: Yes (`verifyAccessToken` required).
* **Request Body**: `{ "refreshToken": "JWT_REFRESH_TOKEN" }`
* **Response (200 OK)**: `{ "success": true, "message": "successfully logged out" }`
* **Errors**: `400` (Missing token / already revoked), `401` (invalid/expired token), `500` (Internal server error).

#### GET `/api/auth/me`
* **Purpose**: Fetches the currently authenticated user's profile details.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { ...userSchemaDetails } }`
* **Errors**: `400` (User not found), `401` (Unauthorized).

#### PUT `/api/auth/me`
* **Purpose**: Updates profile parameters of the active user. Validates image URL format.
* **Auth Required**: Yes.
* **Request Body**: `{ "photoURL": "https://newurl.com/img.jpg", "displayName": "Jane D." }`
* **Response (200 OK)**: `{ "success": true, "data": { ...updatedUserSchemaDetails } }`
* **Errors**: `400` (Empty updates / wrong format validation), `401` (Unauthorized), `500` (Internal server error).

#### POST `/api/auth/forgot-password`
* **Purpose**: Initiates password recovery. If called without OTP arguments, generates and sends a random 6-digit OTP code to the requested email. If called with OTP and token arguments, validates the input and updates the user's password.
* **Auth Required**: No.
* **Request Body**:
  * *Step 1 (Request OTP)*: `{ "email": "jane@college.edu" }`
  * *Step 2 (Verify & Reset)*: `{ "email": "jane@college.edu", "otp": "123456", "forgotPassToken": "JWT_FORGOT_PASS_TOKEN", "newPassword": "newpassword123" }`
* **Response (200 OK)**: `{ "success": true, "message": "Password reset successful" }` (or OTP sent response)
* **Errors**: `400` (Bad request / incorrect inputs), `429` (too many OTP attempts).
* **Critical Design Mismatches / Bugs**:
  * The step 1 branch attempts to return token data but references `token` instead of `newToken` (line 95), raising a ReferenceError.
  * It also leaves the HTTP status empty at line 71: `res.status().json(...)`, which will crash the process.
  * There is no `return` statement after sending the OTP, so execution falls through to verify the (undefined) `forgotPassToken`, causing a verification crash.
  * It signs step 1 tokens using `JWT_SECRET` but verifies them in step 2 with `JWT_ACCESS`.

#### POST `/api/auth/reset-password`
* **Purpose**: Resets password of a logged-in user or validates forgot pass tokens.
* **Auth Required**: No.
* **Request Body**:
  * *Step 1 (Send OTP)*: `{ "email": "jane@college.edu" }`
  * *Step 2 (Reset)*: `{ "email": "jane@college.edu", "otp": "123456", "resetToken": "JWT_RESET_TOKEN", "newPassword": "newpassword123" }`
* **Response (200 OK)**: `{ "message": "Password reset successful" }`
* **Errors**: `400` (expired/incorrect OTP), `401` (invalid payloads), `429` (Max attempts reached).
* **Bugs**: signs reset token with typo key `process.env.JWT_ACEESS` (line 78), but decodes/verifies using `process.env.JWT_ACCESS` (line 97).

#### POST `/api/auth/refresh`
* **Purpose**: Generates a new short-lived access token.
* **Auth Required**: Yes (`verifyRefreshToken` required).
* **Response (200 OK)**: `{ "success": true, "accesToken": "NEW_JWT_ACCESS_TOKEN" }`
* **Errors**: `400` (missing/invalid token), `401` (expired refresh token).

#### GET `/api/auth/verify`
* **Purpose**: Validates active access token status.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Token is valid" }`

---

### 5.2. Users Module (`routes/users/*`)

#### GET `/api/users/search`
* **Purpose**: Searches for users filtering by name, email, department, year, or college.
* **Auth Required**: Yes.
* **Query Params**: `query`, `department`, `academicYear`, `college`, `page`, `limit`
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "data": [{ ...userProfile }],
    "page": 1,
    "limit": 20,
    "totalPages": 1,
    "hasMore": false
  }
  ```
* **Performance Note**: Fetches all matching users into memory first via `userModel.find(searchJson)` to compute length, which causes a performance bottleneck.

#### GET `/api/users/:userId/followers`
* **Purpose**: Fetches a paginated list of followers of the target user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": [followerRecords], "page": 1, "totalPages": 1, "hasMore": false }`

#### GET `/api/user/:userId/following`
* **Purpose**: Fetches a paginated list of accounts followed by the target user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": [followingRecords], "page": 1, "totalPages": 1, "hasMore": false }`
* **Endpoint Note**: Path begins with `/user/` (singular) rather than `/users/`.

#### GET `/api/users/:userId/is-following`
* **Purpose**: Determines whether the logged-in user is currently following the target user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { "isFollowing": true } }`

#### GET `/api/users/:userId`
* **Purpose**: Fetches profile metadata of the target user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { ...userSchema } }`
* **Privacy Rule**: Removes the `email` field from the returned payload if the requested profile ID is not the active logged-in user.

#### POST `/api/users/:userId/follow`
* **Purpose**: Follows a user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "User followed" }`
* **Bug**: Only inserts records into `Following` schema. Failed to record elements in `Follower` schema, breaking data consistency.

#### DELETE `/api/users/:userId/follow`
* **Purpose**: Unfollows a user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "User Unfollowed" }`
* **Bug**: Only removes records from `Following` schema. Leftover records remain in the `Follower` schema.

#### PUT `/api/users/me`
* **Purpose**: Allows user to edit their profile information.
* **Auth Required**: Yes.
* **Request Body**: `{ "displayName": "Jane Doe", "college": "TCET" }`
* **Response (200 OK)**: `{ "success": true, "data": { ...userSchema } }`
* **Errors**: `400` (if `password` changes are attempted).

---

### 5.3. Posts Module (`routes/posts/*`)

#### GET `/api/posts`
* **Purpose**: Returns a paginated list of posts, with optional query filters for visibility scope, department, and academic year.
* **Auth Required**: Yes.
* **Query Params**: `page`, `limit`, `scope` (`college`/`department`/`year`), `department`, `academicYear`
* **Response (200 OK)**:
  ```json
  {
    "success": true,
    "data": {
      "items": [{ ...postSchema }],
      "page": 1,
      "limit": 10,
      "total": 12,
      "totalPages": 2,
      "hasMore": true
    }
  }
  ```
* **Bug**: The `hasMore` logic is incorrect: `hasMore: page < totalCount` (compares page number with item count instead of checking if remaining items exist).

#### GET `/api/posts/:postId`
* **Purpose**: Fetches details of a specific post.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "postData": { ...postSchema } }`

#### GET `/api/posts/:postId/comments`
* **Purpose**: Returns comments left on the target post.
* **Auth Required**: Yes.
* **Response (200 OK)**: `[{ ...commentSchema }]`

#### POST `/api/posts`
* **Purpose**: Publishes a new post to the feed.
* **Auth Required**: Yes.
* **Request Body**: `{ "content": "Post Body", "isAnonymous": false, "visibilityScope": "college", "imageUrl": "..." }`
* **Response (201 Created)**: `{ ...createdPostSchema }`
* **Business Logic**: Sets department and academicYear automatically matching the poster's profile. Sets `userName` only if `isAnonymous` is false.

#### POST `/api/posts/:postId/comments`
* **Purpose**: Adds a comment to a post. Increments `commentCount` on the post document.
* **Auth Required**: Yes.
* **Request Body**: `{ "content": "Awesome post!" }`
* **Response (201 Created)**: `{ ...createdCommentSchema }`

#### POST `/api/posts/:postId/like`
* **Purpose**: Likes a post. Increments `likeCount` on the post document.
* **Auth Required**: Yes.
* **Response (201 Created)**: `{ "success": true, "data": { "likeCount": 1 } }`
* **Bug**: The query to check if a user has already liked the post searches using `postId: postId` instead of `targetId: postId` against `likeModel`. Since `postId` is missing in `likeSchema`, Mongoose ignores it and queries only by `userId` and `targetType: 'post'`. This prevents users from liking more than one post.

#### PUT `/api/posts/:postId`
* **Purpose**: Allows the creator of a post to edit its body or image content.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ ...updatedPostSchema }`
* **Errors**: `403 Forbidden` (if the requester did not write the post).

#### DELETE `/api/posts/:postId`
* **Purpose**: Deletes a post.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "post deleted" }`
* **Errors**: `403 Forbidden` (if the requester is not the author).

#### DELETE `/api/posts/:postId/comments/:commentId`
* **Purpose**: Deletes a comment. Decrements `commentCount` on the parent post.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "comment deleted" }`
* **Bugs**: In `postsDeleteRoute.js` line 55, if the comment does not belong to the post (`postId.toString() !== comment.postId.toString()`), the server calls `res.status(401).json(...)` but does not return, causing execution to continue and throw "Cannot set headers after they are sent to the client".

#### DELETE `/api/posts/:postId/like`
* **Purpose**: Unlikes a post. Decrements `likeCount` on the post document.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { "likeCount": 0 } }`

---

### 5.4. Chats Module (`routes/chats/*`)

#### GET `/api/chats`
* **Purpose**: Returns all chat rooms (DMs and groups) the user is a participant of.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": [chatSchemaRooms] }`

#### GET `/api/chats/:chatId/messages`
* **Purpose**: Returns paginated messages for a chat room.
* **Auth Required**: Yes.
* **Query Params**: `page`, `limit` (max 100)
* **Response (200 OK)**: `{ "success": true, "data": [messages], "page": 1, "limit": 50, "total": 1, "hasMore": false }`

#### GET `/api/chats/:chatId`
* **Purpose**: Retrieves room metadata.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ ...chatSchemaMetadata }`

#### POST `/api/chats/group`
* **Purpose**: Creates a new group chat room.
* **Auth Required**: Yes.
* **Request Body**: `{ "name": "Study Group", "description": "Notes review", "memberIds": ["user1_id", "user2_id"] }`
* **Response (200 OK)**: `{ ...createdGroupChatRoom }`

#### POST `/api/chats/dm/messages/:userId`
* **Purpose**: Sends a DM message to a user. Creates the DM chat room dynamically if it doesn't already exist.
* **Auth Required**: Yes.
* **Request Body**: `{ "text": "Hello!", "type": "text" }`
* **Response (201 Created)**: `{ "success": true, "data": { ...messageSchema } }`
* **Bug**: Updates `lastMessage` with the message text (String) instead of storing the Message ID (ObjectId) as defined in `chatSchema.js` (line 21).

#### POST `/api/chats/:chatId/messages`
* **Purpose**: Sends a message in a group chat room.
* **Auth Required**: Yes.
* **Request Body**: `{ "text": "Hello group", "type": "text" }`
* **Response (201 Created)**: `{ "success": true, "data": { ...messageSchema } }`

#### POST `/api/chats/:chatId/messages/:messageId/read`
* **Purpose**: Appends the active user to the message's `readBy` array.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Message marked as read" }`

#### POST `/api/chats/:chatId/members`
* **Purpose**: Adds members to a group chat.
* **Auth Required**: Yes.
* **Request Body**: `{ "memberIds": ["user_id_1", "user_id_2"] }`
* **Response (200 OK)**: `{ "success": true, "message": "Participants Added" }`
* **Bug**: The code validates permissions using `req.chat.admin.some(...)`, but `admin` in `chatSchema.js` is defined as a single `ObjectId` (not an array), which will cause this check to crash with a TypeError.

#### POST `/api/chats/:chatId/leave`
* **Purpose**: Removes the active user from the room's participant array.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "You left the group" }`
* **Bug**: Treatment of `req.chat.admin` as an array (`req.chat.admin.some`, `req.chat.admin.length`) will crash the runtime.

#### PUT `/api/chats/:chatId`
* **Purpose**: Updates room details (description, name, etc.).
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "chat": { ...chatSchema } }`

#### DELETE `/api/chats/:chatId/messages/:messageId`
* **Purpose**: Deletes a message sent by the user in a chat room.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Message deleted" }`

#### DELETE `/api/chats/:chatId/members/:userId`
* **Purpose**: Removes a user from a group chat.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Admin removed ..." }`
* **Bug**: Accesses `chat.admin.equals(...)` (line 96) which works because Mongoose wraps it as an ObjectId, but the controller populates the `participants` path dynamically, altering room formats and complicating admin checks.

---

### 5.5. Notifications Module (`routes/notifications/*`)

#### GET `/api/notifications`
* **Purpose**: Returns a user's notifications.
* **Auth Required**: Yes.
* **Query Params**: `page`, `limit`, `unreadonly`
* **Response (200 OK)**: `{ "success": true, "data": { "items": [...], "page": 1, "limit": 20, "total": 10, "hasMore": false } }`

#### GET `/api/notifications/unread-count`
* **Purpose**: Returns the count of notifications.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { "count": 10 } }`
* **Bug**: Counts *all* notification documents for the user instead of filtering by `isRead: false`.

#### GET `/api/notifications/settings`
* **Purpose**: Fetches the user's notification preferences.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { ...notificationSettingsSchema } }`

#### PUT `/api/notifications/:notificationId/read`
* **Purpose**: Marks a notification as read.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Notification is marked as read" }`
* **Security Mismatch (IDOR)**: Does not verify that the logged-in user is the recipient of the notification, allowing users to modify any notification.

#### PUT `/api/notifications/read-all`
* **Purpose**: Marks all notifications for the active user as read.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "... is marked as read", "matchedCount": 5, "modifiedCount": 5 }`

#### PUT `/api/notifications/settings`
* **Purpose**: Updates or initializes notification settings for the user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "data": { ...notificationSettingsSchema } }`

#### DELETE `/api/notifications/:notificationId`
* **Purpose**: Deletes a specific notification.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Notification deleted" }`
* **Security Mismatch (IDOR)**: Does not check the owner of the notification, allowing anyone to delete any notification.

#### DELETE `/api/notifications/clear-read`
* **Purpose**: Removes all read notification records for the active user.
* **Auth Required**: Yes.
* **Response (200 OK)**: `{ "success": true, "message": "Read notifications cleared" }`

---

### 5.6. Media Uploads Module (`routes/upload/*`)

#### POST `/api/uploads/chat-image`
* **Purpose**: Uploads a single image for use in a chat.
* **Auth Required**: Yes.
* **Payload**: Form-data with file buffer mapped to field `image`.
* **Response (200 OK)**: `{ "success": true, "data": { "url": "CLOUDINARY_URL" } }`

#### POST `/api/uploads/image`
* **Purpose**: Uploads up to 5 images for a post.
* **Auth Required**: Yes.
* **Payload**: Form-data with file buffers mapped to field `images`.
* **Response (201 Created)**: `{ "success": true, "data": [{ "url": "CLOUDINARY_URL", "publicId": "..." }] }`

#### POST `/api/uploads/profile-photo`
* **Purpose**: Uploads a profile picture and updates the user's `photoURL` field.
* **Auth Required**: Yes.
* **Payload**: Form-data with file buffer mapped to field `image`.
* **Response (200 OK)**: `{ "success": true, "data": { "url": "CLOUDINARY_URL", "publicId": "..." } }`

---

## 6. Authentication & Authorization

### Flows Walkthrough
1. **Registration Flow**: A POST call to `/api/auth/register` creates the user in the database. The system signs an access token (5m validity) and a refresh token (7d validity). The refresh token is hashed via bcrypt and stored in the `Token` collection before both tokens are sent back in the HTTP response.
2. **Login Flow**: A POST call to `/api/auth/login` checks credentials. If valid, the system creates a session token, hashes it, saves it in the database, and returns the tokens in the response.
3. **Session Refresh Flow**: The client sends the refresh token to `/api/auth/refresh`. The `verifyRefreshToken` middleware validates it, confirms it is registered and not revoked, and generates a new access token.
4. **Logout Flow**: The client calls `/api/auth/logout` with the active refresh token. The server marks the token as `isRevoked: true` in the database, invalidating the session.
5. **Password Recovery / Reset**:
   * Forgot password: Sends a verification email containing a random 6-digit OTP code, and returns a short-lived recovery token.
   * Reset password: Password update is verified using the OTP and recovery token before the new password hash is stored.

---

## 7. Middleware Analysis

The middleware pipeline executes validations and permissions sequentially.

### Middleware Reference Table

| Name | Module Path | Purpose | Protected Routes | Execution Order / Side Effects |
|---|---|---|---|---|
| `verifyAccessToken` | [verifyAccessToken.js](file:///d:/web-dev/Ai/campuspulse%20backend/middlewares/verifyAccessToken.js) | Decodes the Bearer token and verifies the signature using `JWT_ACCESS`. | All protected routes | Executes first in the pipeline. Attaches the token payload to `req.user`. |
| `verifyRefreshToken` | [verifyRefreshToken.js](file:///d:/web-dev/Ai/campuspulse%20backend/middlewares/verifyRefreshToken.js) | Validates the refresh token and checks its revocation status in the database. | `/api/auth/refresh` | Executes first on the refresh endpoint. Attaches the token payload to `req.user`. |
| `postValidation` | [postValidation.js](file:///d:/web-dev/Ai/campuspulse%20backend/middlewares/postValidation.js) | Verifies the existence and validity of a `postId` path parameter. | Posts edit/delete/like/comment | Executes after token verification. Attaches the post document to `req.post`. |
| `userValidation` | [userValidation.js](file:///d:/web-dev/Ai/campuspulse%20backend/middlewares/userValidation.js) | Verifies the existence of a `userId` path parameter. | User profiles, follows, and listings | Executes after token verification. Attaches the user profile to `req.presentUser`. |
| `chatVerification` | [chatVerification.js](file:///d:/web-dev/Ai/campuspulse%20backend/middlewares/chatsMiddleware/chatVerification.js) | Checks if the active user is a participant of the specified `chatId`. | Chat messaging, members, details, leaving | Executes after token verification. Attaches the chat document to `req.chat`. |
| `getUserChats` | [getUserChats.js](file:///d:/web-dev/Ai/campuspulse%20backend/middlewares/chatsMiddleware/getUserChats.js) | Retrieves chat rooms where the user is a participant. | `/api/chats` (GET) | Runs user checks. Attaches rooms to `req.chat`. |

---

## 8. Services & Utilities

### 8.1. Cloudinary Buffer Service
* **Utility**: Exposes `uploadBufferToCloudinary(fileBuffer, folder)` inside [cloudinary.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/upload/cloudinary.js).
* **Inputs**:
  * `fileBuffer` (`Buffer`): Binary file data in memory.
  * `folder` (`String`): Destination path folder in Cloudinary.
* **Outputs**: Returns a Promise resolving to the upload result object containing `secure_url` and `public_id`.
* **Dependencies**: `cloudinary` SDK, Multer.

### 8.2. Nodemailer Mailer Service
* **Utility**: Exposes `sendResetOtpMail(email, otp)` inside [forgotPassword.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/auth/forgotPassword.js) and [resetPassword.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/auth/resetPassword.js).
* **Inputs**:
  * `email` (`String`): Recipient address.
  * `otp` (`String`): Random OTP code.
* **Outputs**: Returns a preview URL string if Ethereal test accounts are configured.
* **Dependencies**: `nodemailer` module.

---

## 9. Frontend Analysis

### WebSocket Test Sandbox Client (`index.html`)
The backend codebase contains only one static frontend file, `index.html`, which acts as a WebSocket connection testing sandbox.

* **Purpose**: Allows developers to connect, disconnect, and broadcast messaging frames to a local WebSocket server.
* **Page Features**:
  * Connection Status indicator.
  * **Connect** and **Disconnect** action triggers.
  * Chat messages list log container.
  * Text input form field.
  * Message broadcast button.
* **APIs Consumed**: Exclusively utilizes the native Web API `WebSocket` connecting to `ws://localhost:3000`. Broadcasts frames containing JSON strings:
  ```json
  { "type": "CHAT_MESSAGE", "message": "user input text" }
  ```

---

## 10. State Management

The backend supports stateless client interactions. When building a client interface, the state management model should match the following patterns:

```text
                  +--------------------------------+
                  |         Client App             |
                  |  - authState (Access Token)    |
                  |  - user Affiliation (Scope)    |
                  +---------------+----------------+
                                  |
            HTTPS Requests        |        WebSocket Frames
       (CRUD Posts, DMs, uploads) |    (Real-time text alerts)
                                  v
                  +---------------+----------------+
                  |        Express Server          |
                  | - Access validations           |
                  | - MongoDB persistence          |
                  +--------------------------------+
```

### Key Client Considerations
* **Credentials Store**: Store the JWT `accessToken` in transient memory, and store the `refreshToken` in a secure, persistent location (such as HttpOnly cookies or secure app storage).
* **WebSocket Sync**: Connect to `ws://localhost:3000?token=accessToken` to receive real-time messages.
* **Feed Scope State**: Use visibility attributes (`college`, `department`, `year`) in feeds query strings.

---

## 11. Environment Variables

The project requires the following environment variables:

| Variable | Purpose | Required | Example | Located / Used In |
|---|---|---|---|---|
| `MONGODB_URL` | MongoDB connection URI string | Yes | `mongodb://localhost:27017/mydb` | [mongoDB.js](file:///d:/web-dev/Ai/campuspulse%20backend/database/mongoDB.js) |
| `JWT_ACCESS` | Secret key used to sign and verify access tokens | Yes | `thegamesofwarandlove` | `verifyAccessToken.js`, `loginRoute.js`, `registrationRoute.js`, `refreshToken.js` |
| `JWT_REFRESH` | Secret key used to sign and verify refresh tokens | Yes | `THEgameISneverWONbySOMEONEweak` | `verifyRefreshToken.js`, `loginRoute.js`, `registrationRoute.js` |
| `JWT_SECRET` | Secret key fallback for reset token signatures | Yes | `my_secret` | `forgotPassword.js` |
| `JWT_ACEESS` | Typo key used inside password reset signatures | Yes (due to bug) | `access_fallback` | `resetPassword.js` |
| `SMTP_HOST` | Host address of SMTP server | No (defaults to Ethereal) | `smtp.ethereal.email` | `forgotPassword.js`, `resetPassword.js` |
| `SMTP_PORT` | Port of SMTP server | No | `587` | `forgotPassword.js`, `resetPassword.js` |
| `SMTP_SECURE` | Connect via SSL/TLS check | No | `false` | `forgotPassword.js`, `resetPassword.js` |
| `SMTP_USER` | Username account for SMTP auth | No | `testuser@ethereal.email` | `forgotPassword.js`, `resetPassword.js` |
| `SMTP_PASS` | Password account for SMTP auth | No | `user_password` | `forgotPassword.js`, `resetPassword.js` |
| `SMTP_FROM` | Outbound sender format header | No | `"CampusPulse" <no-reply@cp.local>`| `forgotPassword.js`, `resetPassword.js` |
| `CLOUDINARY_CLOUD_NAME` | Cloudinary storage bucket namespace | Yes (for media uploads) | `dnqkk0xg3` | [cloudinary.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/upload/cloudinary.js) |
| `CLOUDINARY_API_KEY` | Public key credential for Cloudinary API | Yes | `163983731939733` | [cloudinary.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/upload/cloudinary.js) |
| `CLOUDINARY_API_SECRET` | Secret key credential for Cloudinary API | Yes | `PdCuWZn6E3lMWlSYxPJY8cCoUsU` | [cloudinary.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/upload/cloudinary.js) |

---

## 12. Third-Party Integrations

### 12.1. Cloudinary Integration
* **Purpose**: Serves as the primary media hosting service for posts, profile photos, and chat attachments.
* **Integrations File**: [cloudinary.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/upload/cloudinary.js).
* **Data Exchanged**: Binary image buffers are piped to Cloudinary. In return, the API returns a JSON response containing metadata like `secure_url` and `public_id`, which are saved to the user or post records in MongoDB.

### 12.2. Nodemailer Integration
* **Purpose**: Sends OTP verification codes for account recovery and password reset requests.
* **Integrations Files**: [forgotPassword.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/auth/forgotPassword.js) and [resetPassword.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/auth/resetPassword.js).
* **Data Exchanged**: Generates Ethereal test credentials if SMTP env keys are missing. Transmits raw HTML email templates containing OTP passcodes.

---

## 13. Security Review

A detailed security review of the codebase identified the following vulnerabilities and bugs:

1. **Insecure Direct Object Reference (IDOR) on Notifications Deletion**:
   * **Location**: `DELETE /api/notifications/:notificationId` in [notificationDeleteRoute.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/notifications/notificationDeleteRoute.js).
   * **Issue**: The handler calls `notificationModel.findByIdAndDelete(notificationId)` directly without checking the `recipient` field. An authenticated user can delete any notification in the database by passing its ID.
2. **Insecure Direct Object Reference (IDOR) on Notification Read Status**:
   * **Location**: `PUT /api/notifications/:notificationId/read` in [notificationsPutRoute.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/notifications/notificationsPutRoute.js).
   * **Issue**: The server updates the notification read status without validating that the active user is the recipient of the notification.
3. **Secret Key Name Mismatch**:
   * **Location**: [resetPassword.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/auth/resetPassword.js).
   * **Issue**: The recovery token is signed using `process.env.JWT_ACEESS` (three Es) but verified using `process.env.JWT_ACCESS` (two Es), which will cause verification to fail.
4. **Forgot Password Routing Fallthrough & Crash**:
   * **Location**: [forgotPassword.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/auth/forgotPassword.js) line 54.
   * **Issue 1**: The step 1 branch (which sends the OTP email) does not return or stop execution. As a result, execution falls through to step 2, which tries to verify an undefined `forgotPassToken` and crashes.
   * **Issue 2**: The endpoint tries to return a status response using `res.status().json({...})` without passing a status code, which will throw a runtime error in Express.
5. **Response Header Mismatch / Crash in Comments Deletion**:
   * **Location**: [postsDeleteRoute.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/posts/postsDeleteRoute.js) line 55.
   * **Issue**: If the comment postId does not match the route postId, the server calls `res.status(401).json(...)` but does not return. This causes execution to continue and triggers a "Cannot set headers after they are sent to the client" error when it tries to send the success response.
6. **Polymorphic Like Schema Query Bug**:
   * **Location**: [postsPostRoute.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/posts/postsPostRoute.js) line 75.
   * **Issue**: The duplicate check queries `likeModel` using `{ userId, postId, targetType: 'post' }`. However, `likeSchema` defines the post reference field as `targetId` instead of `postId`. This causes Mongoose to ignore the post filter and query only by `userId` and `targetType: 'post'`. As a result, once a user likes *any* post, they are blocked from liking any other post.
7. **Type Crash on Admin Validation in Group Chats**:
   * **Location**: [chatPostRoute.js](file:///d:/web-dev/Ai/campuspulse%20backend/routes/chats/chatPostRoute.js) lines 215 and 296.
   * **Issue**: The code calls `.some(...)` on `chat.admin` to validate permissions. However, `admin` in `chatSchema.js` is defined as a single `ObjectId` rather than an array, which will cause this check to crash.

---

## 14. Current Feature Status

### Completed Features
* **Authentication Infrastructure**: User registration, login, logout, and token refresh routes.
* **Visibility Scopes on Posts**: Filter configurations for year, department, and college visibility.
* **Polymorphic Likes/Comments**: Creation and deletion endpoints for posts and comments.
* **Chat Room Setup**: Creating group chats, direct messaging (DMs), and marking messages as read.
* **Notification System**: Notification settings mapping and general listing.
* **Cloudinary Upload Helpers**: Memory storage wrappers to upload image buffers.

### Partially Implemented Features
* **WebSocket Integration**: WebSocket server logic is completely missing from the server filesystem. The repository only contains `index.html` at the root, which tries a standard connection to `ws://localhost:3000` without authentication parameters. Creating the WebSocket controllers and hooking them into `server.js` remains a future development roadmap task.

### Planned Features
* **Push Notifications**: Mobile push capabilities using services like Firebase.
* **Mentions System**: Automatically parse `@username` in posts/comments to generate notifications.

### Broken Features
* **Follower/Following Graph Sync**: Follow and unfollow operations only update the `Following` collection, leaving the `Followers` collection out of sync.
* **Forgot Password flow**: Broken control flow and empty status parameters cause runtime crashes when requesting recovery codes.
* **Double-like checks**: Schema queries use incorrect property names, preventing users from liking multiple posts.

### Technical Debt
* **Inconsistent Error Responses**: Mix of `{ error: "msg" }` and `{ message: "msg" }` response formats.
* **Inefficient Memory Allocation**: User search calls `userModel.find()` twice, pulling all matches into memory instead of using count queries.
* **Missing Transaction Isolation**: Database operations like comments deletion and count updates do not run in transactions, which can result in inconsistent data if updates fail.

---

## 15. Development Workflow

### Setup Requirements
1. **Node.js**: Requires version 18 or higher.
2. **MongoDB**: Requires a running MongoDB instance.
3. **Cloudinary**: Requires a Cloudinary account.

### Installation
```bash
npm install
```

### Running Locally
```bash
# Start server in development mode (with nodemon)
npm run dev

# Start server in production mode
npm start
```

### Running Tests
The project uses Jest for automated testing. The test suite is modularly organized under the `tests/` subdirectories.
```bash
npm run test
```

---

## 16. AI Working Context

### Architectural Decisions
* **ES Modules**: The project uses ES modules (`"type": "module"` in `package.json`), so all imports must use explicit file extensions (e.g., `import app from './app.js'`).
* **Polymorphic Likes**: Likes use a `targetType` enum (`comment`/`post`) and a unified `targetId` field to support liking different types of resources.
* **Strict Schema Attachment**: Custom route parameters like `postId`, `userId`, and `chatId` should always be validated using their respective middleware components (`postValidation`, `userValidation`, `chatVerification`) to ensure they exist and attach them directly to the request object.

### Rules Future AI Sessions Must Never Break
1. **Explicit Import Extensions**: Do not omit file extensions on local imports (e.g., use `verifyAccessToken.js`, not `verifyAccessToken`).
2. **Mongoose Cast Verification**: Always validate `ObjectId` path parameters using `mongoose.Types.ObjectId.isValid` before making database queries.
3. **Cascade Deletes**: Ensure that deleting a resource also deletes its child documents (e.g., deleting a post must delete its comments and likes) to maintain database consistency.
4. **Hashed Token Revocation**: Ensure that refresh tokens are hashed before being stored in the database.

---

## 17. Known Issues & TODOs

### TODOs & FIXMEs in Codebase
* **WebSocket Integration**: Create the `webSockets/` directory structure, implement `setupWebSocket.js` and connection authentication, and integrate them inside `server.js` using the HTTP server instance.
* **Sync Follow Lists**: Update follow and unfollow routes to update both the `Following` and `Followers` collections.
* **Typo Fixes**:
  * Correct `process.env.JWT_ACEESS` typo in `resetPassword.js` to `JWT_ACCESS`.
  * Rename `followerShema.js` to `followerSchema.js`.
  * Fix spelling of `increament` in routes.

---

## 18. System Architecture Reference

This section serves as the canonical reference for the internal architecture and layers of CampusPulse.

### Architectural Style
The application is structured as a **Monolithic Backend Service** containing modular routing namespaces.
* **Monolith vs Microservice**: Single process Express server that manages both standard REST API traffic and upgrading HTTP connections to real-time WebSockets.
* **MVC Boundaries**:
  * **Model**: Represented by Mongoose Schemas defined in `database/schema/**/*.js`.
  * **View**: The service serves no backend-driven views (HTML/CSS engines) to clients, exposing only a raw JSON API. The root folder contains a static `index.html` file used solely for sandbox debugging.
  * **Controller**: Contained inside modular Express Routers defined in `routes/**/*.js`.
* **Persistence Boundaries**: Relies on a single, isolated MongoDB database. Inter-document references are maintained at the application layer via Mongoose `.populate()`, rather than using physical database foreign key constraints.

---

### Layer Definitions

```
+-----------------------------------------------------------+
|                        CLIENT LAYER                       |
|           React / Native App / WebSocket Sandbox          |
+-----------------------------+-----------------------------+
                              | HTTPS / WS
                              v
+-----------------------------------------------------------+
|                          API LAYER                        |
|              Express Router Namespace (/api)              |
+-----------------------------+-----------------------------+
                              |
                              v
+-----------------------------------------------------------+
|                      MIDDLEWARE LAYER                     |
|           Token Verify -> Resource Validation Filters      |
+-----------------------------+-----------------------------+
                              |
                              v
+-----------------------------------------------------------+
|                 BUSINESS LOGIC / ROUTER LAYER             |
|              Controllers processing CRUD operations       |
+-----------------------------+-----------------------------+
                              |
                              v
+-----------------------------------------------------------+
|                     PERSISTENCE LAYER                     |
|             Mongoose Schemas -> MongoDB Engine            |
+-----------------------------------------------------------+
```

#### Client Layer
* **Responsibilities**: User interface rendering, client-side session persistence (storing access tokens in memory, refresh tokens in storage), local state updating, and WebSocket stream handling.
* **Inputs**: User input events, REST responses (JSON), WebSocket broadcast frames.
* **Outputs**: Form-data uploads, REST request bodies, and outgoing WebSocket text events.
* **Dependencies**: Web Browser / WebView API and socket network streams.

#### API Layer
* **Responsibilities**: Listening on port `3000`, routing requests, checking route constraints, parsing request bodies, and generating serialized JSON payloads.
* **Routes**: Modular route files mounted at `/api` using Express Routers.
* **Validation Responsibilities**: Checking query arguments, converting strings into integers for pagination limits, and validating format strings (e.g., emails) via the `validator` package.
* **Authentication Responsibilities**: Extracting Bearer headers and delegating token validation to verification middlewares.

#### Middleware Layer
* **Responsibilities**: intercepting routes to inspect token signatures, looking up referenced records (such as posts, chats, users) to confirm existence, and checking authorization.
* **Execution Order**:
  1. Token verification: `verifyAccessToken` or `verifyRefreshToken` is executed to establish identity.
  2. Resource validation: `postValidation`, `userValidation`, or `chatVerification` is executed to load target records.
  3. Controller execution: The target route handler executes.
* **Attached Request Properties**:
  * `req.user`: Contains validated payload fields (`userId`, `email`, `type`, `tokenId`).
  * `req.post`: Contains target Mongoose document loaded by `postValidation.js`.
  * `req.presentUser`: Contains target user Mongoose document loaded by `userValidation.js`.
  * `req.chat`: Contains target chat Mongoose document loaded by `chatVerification.js`.
* **Failure Behaviors**: Stops route execution immediately if validation fails, returning a standard JSON error response (e.g., `res.status(401).json({ error: "Invalid token" })`).

#### Business Logic Layer
* **State of Logic**: Business rules are currently implemented inline inside the route handler files under the `routes/` folder.
* **Duplicated Logic**:
  * **Password Hashing**: Cryptographic password generation is duplicated in `/auth/register`, `/auth/forgot-password`, and `/auth/reset-password`.
  * **SMTP Transporter Configuration**: Setup for Nodemailer transports is duplicated in `forgotPassword.js` and `resetPassword.js`.
* **Misplaced Logic**: File upload buffer processing and schema updates (like incrementing likes and comments) are managed directly inside the routing layer.
* **Reusable Logic Candidates**:
  * **Mail Dispatch Service**: Standardized mailer wrapper.
  * **Media Upload Manager**: Standardized Cloudinary upload client.
  * **Notification Dispatcher**: Centralized notification creation service.

#### Persistence Layer
* **Models**: 11 Mongoose collections mapped to MongoDB.
* **Relationships**: Relational links maintained using Mongoose `Types.ObjectId` references.
* **Indexes**: Compounds `{ recipient: 1, createdAt: -1 }` on Notifications, TTL index of 120s on OTP `createdAt` field, and unique indexes on User `email` and `userName`.
* **Query Patterns**: Paginated queries using `.skip(skip).limit(limit).sort({ createdAt: -1 })`.

---

### Data Flow Diagrams

#### Authentication Flow
```mermaid
sequenceDiagram
    autonumber
    actor User as Client
    participant Route as Express Router
    participant MW as verifyAccessToken MW
    participant DB as MongoDB (User Schema)
    
    User->>Route: Request to protected path (GET /api/auth/me) with Bearer token
    Route->>MW: Check credentials
    alt Token Missing or Expired
        MW-->>User: 401 Unauthorized (stops request)
    else Signature Valid
        MW->>DB: findById(verify.userId) without password
        DB-->>MW: User Document
        MW->>Route: Set req.user & next()
        Route-->>User: 200 OK with User data
    end
```

#### Posts Flow
```mermaid
sequenceDiagram
    autonumber
    actor User as Poster
    participant Route as Posts Router
    participant MW as postValidation MW
    participant DB as MongoDB (Post / User Models)
    participant Notif as Notification Engine
    
    User->>Route: Create comment on post (POST /api/posts/:postId/comments)
    Route->>MW: Run validation checks
    MW->>DB: findById(postId)
    alt Post Not Found
        MW-->>User: 404 Not Found (stops request)
    else Post Exists
        MW->>Route: Set req.post & next()
        Route->>DB: Create Comment Document
        Route->>DB: Increment post.commentCount
        Route->>Notif: Trigger user notification
        Route-->>User: 201 Created with Comment data
    end
```

#### Messaging Flow
```mermaid
sequenceDiagram
    autonumber
    actor User as Sender
    participant Route as Chat Router
    participant MW as chatVerification MW
    participant DB as MongoDB (Message / Chat Models)
    
    User->>Route: Send message in group (POST /api/chats/:chatId/messages)
    Route->>MW: Run checks
    MW->>DB: findOne(chatId, participants: userId)
    alt Unauthorized/Not Participant
        MW-->>User: 403 Forbidden / 404 Not Found
    else Authorized
        MW->>Route: Set req.chat & next()
        Route->>DB: Create Message Document
        Route->>DB: Update chat.lastMessage & lastActivity
        Route-->>User: 201 Created with Message data
    end
```

---

## 19. Route Dependency Matrix

Below is the dependency matrix mapping inputs, validations, database models, and side effects for every route.

### 19.1. Authentication Routes (`routes/auth/`)

| Endpoint | Method | Models Used | Middlewares | Side Effects |
|---|---|---|---|---|
| `/auth/register` | POST | `userModel`, `tokenModel` | *None* | Creates User, hashes password, generates Access/Refresh tokens, saves Refresh token in DB. |
| `/auth/login` | POST | `userModel`, `tokenModel` | *None* | Validates email/password, generates tokens, saves bcrypt-hashed Refresh token in DB. |
| `/auth/logout` | POST | `tokenModel` | `verifyAccessToken` | Sets `isRevoked: true` on the active refresh token in the database. |
| `/auth/me` | GET | `userModel` | `verifyAccessToken` | Retrieves active user profile information. |
| `/auth/me` | PUT | `userModel` | `verifyAccessToken` | Updates active user profile fields (validates image/email formats). |
| `/auth/forgot-password` | POST | `userModel`, `otpModel` | *None* | Generates and sends a 6-digit OTP email (Step 1) OR verifies token and updates password (Step 2). |
| `/auth/reset-password` | POST | `userModel`, `otpModel` | *None* | Generates and sends a 6-digit OTP email (Step 1) OR updates user password (Step 2). |
| `/auth/refresh` | POST | *None* | `verifyRefreshToken` | Validates refresh token and generates a new access token. |
| `/auth/verify` | GET | *None* | `verifyAccessToken` | Confirms access token status and validity. |

### 19.2. User Routes (`routes/users/`)

| Endpoint | Method | Models Used | Middlewares | Side Effects |
|---|---|---|---|---|
| `/users/search` | GET | `userModel` | `verifyAccessToken` | Searches profiles with paginated matching options. |
| `/users/:userId/followers` | GET | `followerModel` | `verifyAccessToken`, `userValidation` | Lists followers of the target user profile. |
| `/user/:userId/following` | GET | `followingModel` | `verifyAccessToken`, `userValidation` | Lists followed accounts of the target user profile. |
| `/users/:userId/is-following` | GET | `followingModel` | `verifyAccessToken`, `userValidation` | Returns connection status boolean details. |
| `/users/:userId` | GET | `userModel` | `verifyAccessToken`, `userValidation` | Returns profile fields. Redacts `email` for other users. |
| `/users/:userId/follow` | POST | `followingModel` | `verifyAccessToken`, `userValidation` | **Bug**: Only inserts a following record, leaving the followers collection out of sync. |
| `/users/:userId/follow` | DELETE | `followingModel` | `verifyAccessToken`, `userValidation` | **Bug**: Only deletes the following record, leaving the followers collection out of sync. |
| `/users/me` | PUT | `userModel` | `verifyAccessToken` | Updates user details. Rejects password changes. |

### 19.3. Post Routes (`routes/posts/`)

| Endpoint | Method | Models Used | Middlewares | Side Effects |
|---|---|---|---|---|
| `/posts` | GET | `postModel` | `verifyAccessToken` | Fetches posts with visibility scope filters. |
| `/posts/:postId` | GET | `postModel` | `verifyAccessToken`, `postValidation` | Fetches details for a specific post. |
| `/posts/:postId/comments` | GET | `commentModel` | `verifyAccessToken`, `postValidation` | Returns paginated comments of a post. |
| `/posts` | POST | `postModel`, `userModel` | `verifyAccessToken` | Creates a new post. Automatically injects user affiliation info. |
| `/posts/:postId/comments` | POST | `commentModel`, `postModel` | `verifyAccessToken`, `postValidation` | Saves comment document and increments parent `commentCount`. |
| `/posts/:postId/like` | POST | `likeModel`, `postModel` | `verifyAccessToken`, `postValidation` | **Bug**: Tries to search by `postId` in `likeModel`, preventing users from liking multiple posts. |
| `/posts/:postId` | PUT | `postModel` | `verifyAccessToken`, `postValidation` | Updates post contents. Checks author ownership. |
| `/posts/:postId` | DELETE | `postModel` | `verifyAccessToken`, `postValidation` | Deletes post document. Checks author ownership. |
| `/posts/:postId/comments/:commentId` | DELETE | `commentModel`, `postModel` | `verifyAccessToken`, `postValidation` | Deletes comment document and decrements parent `commentCount`. |
| `/posts/:postId/like` | DELETE | `likeModel`, `postModel` | `verifyAccessToken`, `postValidation` | Deletes like document and decrements parent `likeCount`. |

### 19.4. Chat Routes (`routes/chats/`)

| Endpoint | Method | Models Used | Middlewares | Side Effects |
|---|---|---|---|---|
| `/chats` | GET | `chatModel` | `verifyAccessToken`, `getUserChats` | Returns active user chat rooms. |
| `/chats/:chatId/messages` | GET | `messageModel` | `verifyAccessToken`, `chatVerification` | Returns messages for a chat room. |
| `/chats/:chatId` | GET | *None* | `verifyAccessToken`, `chatVerification` | Returns details for a chat room. |
| `/chats/group` | POST | `chatModel` | `verifyAccessToken` | Creates group room document. |
| `/chats/dm/messages/:userId` | POST | `chatModel`, `messageModel`, `userModel` | `verifyAccessToken` | Sends a message. Dynamically creates the room if it does not exist. |
| `/chats/:chatId/messages` | POST | `messageModel` | `verifyAccessToken`, `chatVerification` | Saves message document to the database. |
| `/chats/:chatId/messages/:messageId/read` | POST | `messageModel` | `verifyAccessToken`, `chatVerification` | Appends active user to message `readBy` array. |
| `/chats/:chatId/members` | POST | `chatModel`, `userModel` | `verifyAccessToken`, `chatVerification` | **Bug**: Checks `req.chat.admin.some(...)` against a single ObjectId. |
| `/chats/:chatId/leave` | POST | `chatModel` | `verifyAccessToken`, `chatVerification` | **Bug**: Checks `req.chat.admin.some(...)` against a single ObjectId. |
| `/chats/:chatId` | PUT | `chatModel` | `verifyAccessToken`, `chatVerification` | Edits chat properties. |
| `/chats/:chatId/messages/:messageId` | DELETE | `messageModel` | `verifyAccessToken`, `chatVerification` | Deletes a message (owner check applied). |
| `/chats/:chatId/members/:userId` | DELETE | `chatModel` | `verifyAccessToken`, `chatVerification` | Removes user participant from group (admin validation checks). |

### 19.5. Notification Routes (`routes/notifications/`)

| Endpoint | Method | Models Used | Middlewares | Side Effects |
|---|---|---|---|---|
| `/notifications` | GET | `notificationModel` | `verifyAccessToken` | Retrieves user's notification list. |
| `/notifications/unread-count` | GET | `notificationModel` | `verifyAccessToken` | **Bug**: Returns total notification count instead of filtering by `isRead: false`. |
| `/notifications/settings` | GET | `notificationSettingsModel` | `verifyAccessToken` | Retrieves user's alert configuration. |
| `/notifications/:notificationId/read` | PUT | `notificationModel` | `verifyAccessToken` | **Bug**: Marks notification as read without owner verification (IDOR). |
| `/notifications/read-all` | PUT | `notificationModel` | `verifyAccessToken` | Sets `isRead: true` for all notifications of the user. |
| `/notifications/settings` | PUT | `notificationSettingsModel` | `verifyAccessToken` | Updates user settings. |
| `/notifications/:notificationId` | DELETE | `notificationModel` | `verifyAccessToken` | **Bug**: Deletes notification without owner verification (IDOR). |
| `/notifications/clear-read` | DELETE | `notificationModel` | `verifyAccessToken` | Deletes all read notifications of the user. |

### 19.6. Upload Routes (`routes/upload/`)

| Endpoint | Method | Helpers Used | Middlewares | Side Effects |
|---|---|---|---|---|
| `/uploads/chat-image` | POST | `uploadBufferToCloudinary` | `verifyAccessToken` | Uploads chat image and returns Cloudinary URL. |
| `/uploads/image` | POST | `uploadBufferToCloudinary` | `verifyAccessToken` | Uploads post images and returns URLs. |
| `/uploads/profile-photo` | POST | `uploadBufferToCloudinary` | `verifyAccessToken` | Uploads photo and updates user's `photoURL` configuration. |

---

## 20. Database Relationship Contracts

This contract maps data integrity rules and lists risks in the current schema design.

### 20.1. Users ↔ Posts
* **Cascade Rule**: Deleting a User should delete their posts, comments, likes, and notification records.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Orphaned post and comment documents remaining in the database.

### 20.2. Users ↔ Sessions (Tokens)
* **Cascade Rule**: Deleting a User should delete all active refresh tokens in the `tokens` collection.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Active sessions remain in the database for non-existent users.

### 20.3. Users ↔ OTP Records
* **Cascade Rule**: Deleting a User should delete their pending verification and reset OTP records.
* **Current Status**: ❌ Not Implemented (relies on MongoDB TTL index expiration).
* **Risk**: Temporary password reset codes remain valid until the expiration window closes.

### 20.4. Users ↔ Group Chats
* **Cascade Rule**: Deleting a User should remove them from all group chat participant lists. If the user is the only admin, a new admin must be assigned before deletion.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Deleted users remain in groups, and groups can be left without any admin.

### 20.5. Users ↔ Follow Lists
* **Cascade Rule**: Deleting a User should delete all their follower and following relationships.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Leftover follow references pointing to deleted accounts.

### 20.6. Posts ↔ Comments
* **Cascade Rule**: Deleting a Post must delete all associated comment records.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Orphaned comment documents remaining in the database.

### 20.7. Posts ↔ Likes
* **Cascade Rule**: Deleting a Post must delete all associated like records.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Orphaned like documents remaining in the database.

### 20.8. Chats ↔ Message History
* **Cascade Rule**: Deleting a chat room must delete all associated message records.
* **Current Status**: ❌ Not Implemented.
* **Risk**: Orphaned message logs remaining in the database.

---

## 21. API Response Contracts

To maintain API consistency, all endpoints must adhere to these response formats.

### 21.1. Common Error Formats

#### Success Response (Standard)
```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": {}
}
```

#### Error Response (General)
```json
{
  "success": false,
  "message": "Reason for operation failure"
}
```

#### Validation Error (HTTP 400)
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": {
    "email": "Please enter a valid email format"
  }
}
```

#### Authorization Error (HTTP 401)
```json
{
  "success": false,
  "message": "Token is missing"
}
```

#### Not Found Error (HTTP 404)
```json
{
  "success": false,
  "message": "Requested resource could not be located"
}
```

---

### 21.2. Consistency Report
An audit of route response formats identified the following inconsistencies:
* **Routes returning raw Mongoose objects directly**: `/api/posts` (POST), `/api/posts/:postId` (GET), `/api/chats/group` (POST).
* **Routes using `error` properties instead of `message`**: `/api/auth/me` (GET), `/api/posts/:postId/like` (POST), `/api/chats/:chatId/messages` (POST).
* **Routes returning properties directly on root instead of nesting inside `data`**: `/api/auth/register` (returns user inside `User` key), `/api/auth/refresh` (returns token inside `accesToken` key).

#### Recommendation for Unified Standard
Update all endpoints to return a standardized wrapper format:
```json
{
  "success": boolean,
  "message": string,
  "data": object | array | null
}
```

---

## 22. Performance Analysis

### 22.1. Heavy Queries & Bottlenecks
* **In-Memory User Search**: The search endpoint (`/users/search`) fetches all matches into memory to calculate page count (`let totalUsers = await userModel.find(searchJson)`), creating a performance bottleneck as the database grows.
* **Missing Likes Index**: `likeModel` queries by `userId` and `targetId` to check duplicate likes. The collection lacks compound indexes on these fields, resulting in full collection scans on large tables.
* **Missing Follower/Following Indexes**: Lookups for follower and following lists lack indexes on `userId`, resulting in slow lookups.
* **Unprojected Chat Populates**: Fetching chat lists populates all participant fields, which transfers unnecessary data (like password hashes, though redacted by `{ password: 0 }`) over the network.

---

### 22.2. Optimization Opportunities

| Current Pattern | Recommended Pattern | Impact Estimation |
|---|---|---|
| `let totalUsers = await userModel.find(searchJson)` | `let total = await userModel.countDocuments(searchJson)` | **High**: Reduces database memory usage by returning only the count instead of full documents. |
| `postModel.find(filter)` | `postModel.find(filter).lean()` | **Medium**: Bypasses Mongoose document instantiation for read-only queries, reducing CPU overhead. |
| `followingModel.find({userId})` | Add Index `{ userId: 1, followingId: 1 }` | **High**: Replaces full collection scans with index seeks for follow checks. |
| `likeModel.findOne({userId, targetId})` | Add Index `{ userId: 1, targetId: 1, targetType: 1 }` | **High**: Optimizes duplicate checks for likes. |

---

## 23. Security Architecture

This section documents security controls and risks in the current backend design.

### 23.1. Security Architecture Breakdown
* **Authentication**: Managed via JWT access tokens signed with `process.env.JWT_ACCESS` (short-lived) and refresh tokens signed with `process.env.JWT_REFRESH` (revocable).
* **Authorization**: Handled via custom middleware. However, some admin-only and participant checks lack proper validations.
* **Password Handling**: Hashed using `bcrypt` with 10 salt rounds. New password checks ensure users cannot reset their password to their current password.
* **Refresh Token Handling**: Stored hashed in the database. When revoked on logout, the token state is set to `isRevoked: true`.
* **Upload Security**: Uses Multer memory storage buffers to upload files directly to Cloudinary without writing files to local disk, mitigating local file execution risks.
* **Input Validation**: Uses the `validator` package for format validation in route handlers.
* **Ownership Checks**: Implemented in `/posts/:postId` (PUT/DELETE) and `/chats/:chatId/messages/:messageId` (DELETE) to ensure users can only modify their own resources.
* **NoSQL Injection Risks**: Schema validation is implemented using Mongoose, but query parameters lack strict sanitization (e.g., passing query objects like `{$ne: null}` inside JSON inputs is not fully sanitized).

---

### 23.2. Security Severity Table

| Severity | Vulnerability | File / Endpoint | Risk |
|---|---|---|---|
| **Critical** | IDOR Notification Deletion | `DELETE /api/notifications/:notificationId` | Authenticated users can delete any user's notifications. |
| **Critical** | IDOR Notification Read Toggle | `PUT /api/notifications/:notificationId/read` | Authenticated users can mark any user's notifications as read. |
| **High** | Reset Token Verification Failure | `/api/auth/reset-password` | Signing tokens using `JWT_ACEESS` but verifying with `JWT_ACCESS` blocks the reset flow. |
| **High** | Double-Response crash (Express crash) | `DELETE /api/posts/:postId/comments/:commentId` | Omission of `return` on verification failure causes the server to crash. |
| **Medium** | Follower Graph Desync | `/api/users/:userId/follow` | Unfollowing/following updates `Following` but leaves `Follower` documents intact. |
| **Low** | Missing Password change in `/users/me` | `/api/users/me` | Rejects password updates without directing to reset routes. |

---

## 24. Project Standards

All future development must adhere to the following project standards:

### 24.1. Naming Conventions
* **Models**: PascalCase (e.g., `userModel`, `tokenModel`). File names must follow camelCase with schema suffixes (e.g., `userSchema.js`).
* **Routes**: File names must follow camelCase with route suffixes (e.g., `registrationRoute.js`, `postsGetsRoute.js`).
* **Variables**: camelCase.
* **Environment Variables**: UPPER_CASE (e.g., `MONGODB_URL`, `JWT_ACCESS`).

### 24.2. Response Standards
All API endpoints must return the standard response format:
```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": {}
}
```
Do not return raw database records directly. Nest payloads inside the `data` key.

### 24.3. Error Handling Standards
* Use appropriate HTTP status codes:
  * `400 Bad Request` for validation failures.
  * `401 Unauthorized` for token verification failures.
  * `403 Forbidden` for ownership/authorization failures.
  * `404 Not Found` for missing resources.
  * `429 Too Many Requests` for OTP limit violations.
  * `500 Internal Server Error` for system crashes.
* Always return a descriptive error message in the response body:
  ```json
  { "success": false, "message": "Descriptive error message" }
  ```

### 24.4. Validation Standards
* Verify `ObjectId` parameters using `mongoose.Types.ObjectId.isValid` before making queries.
* Validate user ownership for updates and deletions.
* Use the validation middleware pipeline for common checks:
  * `verifyAccessToken` -> Authentication
  * `postValidation` -> Post validation
  * `userValidation` -> User validation
  * `chatVerification` -> Chat participant validation

---

## 25. Frontend Integration Guide

This guide details how frontends should consume this API.

### 25.1. Session Token Storage
* Save `accessToken` in transient memory (e.g. React context state).
* Save `refreshToken` in a secure location (e.g., HttpOnly secure cookies, or SecureStore for native applications).

---

### 25.2. Silent Refresh Loop
Implement an interceptor to refresh the access token before it expires:

```javascript
// Axios request interceptor logic
axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    if (error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        const res = await axios.post('/api/auth/refresh', {}, {
          headers: { Authorization: `Bearer ${refreshToken}` }
        });
        const newAccessToken = res.data.accesToken;
        axios.defaults.headers.common['Authorization'] = `Bearer ${newAccessToken}`;
        originalRequest.headers['Authorization'] = `Bearer ${newAccessToken}`;
        return axios(originalRequest);
      } catch (refreshError) {
        // Redirect to login if refresh fails
        logoutUser();
      }
    }
    return Promise.reject(error);
  }
);
```

---

### 25.3. WebSocket Integration Handshake
To connect to the WebSocket server, pass the access token in the query parameters:
```javascript
const ws = new WebSocket(`ws://localhost:3000?token=${accessToken}`);
ws.onmessage = (event) => {
  const payload = JSON.parse(event.data);
  if (payload.type === 'WELCOME') {
    console.log('Connected to real-time server');
  }
};
```

---

### 25.4. React Query Caching Suggestions
* **Queries Key Structures**:
  * `['posts', visibilityScope, filterDepartment]` for post feeds.
  * `['chats', activeUserId]` for chat lists.
  * `['messages', chatId]` for message history.
* **Optimistic Updates**: Use optimistic updates when liking posts. Update `likeCount` in the UI immediately, and rollback if the API request fails.
* **Cache Invalidation**: Invalidate `['comments', postId]` when a comment is added, and invalidate `['posts']` when a new post is created.

---

## 26. Development Roadmap

This roadmap ranks development tasks and lists issues identified in the codebase.

```
                  +----------------------------------------------+
                  |              DEVELOPMENT ROADMAP             |
                  +----------------------+-----------------------+
                                         |
            Critical / High Priority     |     Medium / Low Priority
       +---------------------------------+----------------------------------+
       | - Fix security vulnerabilities  | - Implement push alerts          |
       | - Fix password reset typos      | - Clean up search performance    |
       | - Sync follower graphs          | - Standardize API responses      |
       | - Connect WebSockets            | - Write missing unit tests       |
       +---------------------------------+----------------------------------+
```

### 26.1. High Priority (Critical)
* **Resolve IDOR Vulnerabilities**: Fix notification read and delete endpoints to check user authorization (Critical).
* **Fix Password Reset Key Typo**: Correct `process.env.JWT_ACEESS` typo in `resetPassword.js` (Critical).
* **Fix Follow Graph Sync**: Update follow and unfollow endpoints to synchronize database collections (High).
* **WebSocket Integration**: Connect `setupWebSocket` wrapper in `server.js` and implement message handlers (High).

### 26.2. Medium Priority
* **Fix Duplicate Likes Query**: Update duplicate likes check to query by `targetId` instead of `postId` (Medium).
* **Implement Transaction Isolation**: Run multi-document updates in Mongoose database transactions (Medium).
* **Standardize API Responses**: Update endpoints to use the standard JSON response format (Medium).

### 26.3. Low Priority
* **Optimize Search Queries**: Refactor `/users/search` to use count queries instead of loading all matching profiles into memory (Low).
* **Write Unit Tests**: Fix the syntax error in `tests/Authentication.test.js` and implement missing test suites (Low).

---

## 27. AI Change Log

### 2026-06-14
* **Changes**: Evolved `CONTEXT.md` into a complete AI Memory and Project Architecture System by adding Sections 18-29.
* **Files Modified**: [CONTEXT.md](file:///d:/web-dev/Ai/campuspulse%20backend/CONTEXT.md)
* **Reason**: Ensure documentation serves as the single source of truth for architectural references, database contracts, and security rules.
* **Potential Risks**: None.
* **Testing Required**: Visual inspection of markdown file rendering and links.

---

## 28. AI Working Rules

Future AI sessions must adhere to the following rules:

1. **Verify Context First**: Always read `CONTEXT.md` before making any changes.
2. **Document Code Changes**: Update `CONTEXT.md` immediately after changing database schemas, routers, or middlewares.
3. **Log Actions**: Record changes in the **AI Change Log** (Section 27) at the end of every session.
4. **Follow Project Standards**: Maintain standard naming conventions, response structures, and error codes (Section 24).
5. **No Validation Bypasses**: Always use the validation middleware pipeline for input and authentication checks.
6. **Enforce Ownership Checks**: Always verify user permissions before performing updates or deletions.

---

## 29. Project Health Report

| Category | Score | Justification |
|---|---|---|
| **Architecture** | 6.5 / 10 | Route organization is clean, but WebSocket connection handling is missing from the server configuration. |
| **Security** | 4.0 / 10 | Critical IDOR vulnerabilities exist in notifications, and typos in JWT secret keys prevent password resets. |
| **Performance** | 5.5 / 10 | Database queries lack necessary indexes, and in-memory search operations create bottlenecks. |
| **Code Quality** | 7.0 / 10 | Coding style is consistent, but error handling is not fully standardized across routes. |
| **Scalability** | 5.5 / 10 | Missing indexes and lack of transaction management limit database scalability. |
| **Maintainability**| 7.0 / 10 | Route registration and middleware patterns are modular and easy to maintain. |
| **Documentation** | 9.5 / 10 | Complete, comprehensive `CONTEXT.md` file maps out all system endpoints, database schemas, and architectural patterns. |
| **Testing** | 3.0 / 10 | Test suites are broken and lack coverage for core features. |
| **Cumulative Score**| **6.0 / 10** | **Status**: Active Backend Beta (Requires immediate security patches and WebSocket integration). |

